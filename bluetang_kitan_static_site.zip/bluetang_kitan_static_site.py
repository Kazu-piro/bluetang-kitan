import zipfile
import os

# デモ用の静的サイト構造を作成
site_name = 'bluetang_kitan'
os.makedirs(f'{site_name}/content', exist_ok=True)
os.makedirs(f'{site_name}/static/js', exist_ok=True)
os.makedirs(f'{site_name}/static/css', exist_ok=True)
os.makedirs(f'{site_name}/layouts', exist_ok=True)

# Markdown記事作成
with open(f'{site_name}/content/shekki.md', 'w', encoding='utf-8') as f:
    f.write('# アゼルバイジャンの街・シェキ\n\n隠遁後のダルタニャンの眼差しで、シェキの街を歩く...（旅行記本文）')

with open(f'{site_name}/content/bukowski.md', 'w', encoding='utf-8') as f:
    f.write('# 街で一番の美女（書評）\n\nブコウスキの短編を静かに観察する...（書評本文）')

# ミニゲーム用JS（簡易Wordle風）
js_code = '''
document.addEventListener('DOMContentLoaded', function(){
  const word = '氷壁';
  const input = document.createElement('input');
  input.maxLength = 2;
  const button = document.createElement('button');
  button.textContent = '挑戦';
  const result = document.createElement('div');
  document.body.append(input, button, result);
  button.onclick = ()=>{
    if(input.value === word){
      result.textContent = '正解！';
    } else {
      result.textContent = '違う…';
    }
  };
});
'''
with open(f'{site_name}/static/js/game.js','w', encoding='utf-8') as f:
    f.write(js_code)

# CSS（簡易古風デザイン）
css_code = '''
body { font-family: serif; background: #f4ecd8; color: #3b1f0b; margin: 2em; }
h1 { font-family: 'Georgia', serif; color: #802000; }
''' 
with open(f'{site_name}/static/css/style.css','w', encoding='utf-8') as f:
    f.write(css_code)

# トップページHTML
html_code = '''
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>ブルータン喜譚</title>
<link rel="stylesheet" href="/css/style.css">
</head>
<body>
<h1>ブルータン喜譚</h1>
<nav>
<a href="/content/shekki.md">シェキ旅行記</a> | 
<a href="/content/bukowski.md">街で一番の美女 書評</a> | 
<a href="/static/js/game.js">小遊戯（Wordle風）</a>
</nav>
</body>
</html>
'''
with open(f'{site_name}/index.html','w', encoding='utf-8') as f:
    f.write(html_code)

# ZIP化
zip_filename = f'{site_name}.zip'
with zipfile.ZipFile(zip_filename,'w') as zipf:
    for root, dirs, files in os.walk(site_name):
        for file in files:
            zipf.write(os.path.join(root, file),
                       os.path.relpath(os.path.join(root, file), site_name))

zip_filename
